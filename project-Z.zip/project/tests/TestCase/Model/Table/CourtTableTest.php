<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\CourtTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\CourtTable Test Case
 */
class CourtTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Model\Table\CourtTable
     */
    public $Court;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.court'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('Court') ? [] : ['className' => CourtTable::class];
        $this->Court = TableRegistry::getTableLocator()->get('Court', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Court);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
