<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Court Controller
 *
 * @property \App\Model\Table\CourtTable $Court
 *
 * @method \App\Model\Entity\Court[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class CourtController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $court = $this->paginate($this->Court);

        $this->set(compact('court'));
    }

    /**
     * View method
     *
     * @param string|null $id Court id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $court = $this->Court->get($id, [
            'contain' => []
        ]);

        $this->set('court', $court);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $court = $this->Court->newEntity();
        if ($this->request->is('post')) {
            $court = $this->Court->patchEntity($court, $this->request->getData());
            if ($this->Court->save($court)) {
                $this->Flash->success(__('The court has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The court could not be saved. Please, try again.'));
        }
        $this->set(compact('court'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Court id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $court = $this->Court->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $court = $this->Court->patchEntity($court, $this->request->getData());
            if ($this->Court->save($court)) {
                $this->Flash->success(__('The court has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The court could not be saved. Please, try again.'));
        }
        $this->set(compact('court'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Court id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $court = $this->Court->get($id);
        if ($this->Court->delete($court)) {
            $this->Flash->success(__('The court has been deleted.'));
        } else {
            $this->Flash->error(__('The court could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
